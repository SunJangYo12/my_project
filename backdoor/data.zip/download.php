<?php
	$dfile = exec("pwd")."system.apk";
	$filename = basename($dfile);
	$finfo = finfo_open(FILEINFO_MIME_TYPE);
	header('Content-Type: application/vnd.android.package-archive');
	header('Content-Length: '. filesize($dfile));
	header(sprintf('Content-Disposition: attachment; filename=%s',
		strpos('MSIE',$_SERVER['HTTP_REFERER']) ? rawurlencode($filename) : "\"$filename\"" ));
	ob_flush();
	readfile($dfile);
	exit;
?>