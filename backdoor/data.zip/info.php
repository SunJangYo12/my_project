<?php

	phpinfo()
?>
